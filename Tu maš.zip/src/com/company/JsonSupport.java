package com.company;

public interface JsonSupport {
    public void toJson();
    public void fromJson();
}
