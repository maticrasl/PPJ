package com.company;

public interface Searchable {
    public boolean search(String s);
}
